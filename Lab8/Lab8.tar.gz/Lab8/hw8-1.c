#include "reg51.h"
#include "stdio.h"

void main (void)
{
SCON=0x0D0;                   /* SCON: mode 2, 9-bit UART, enable rcvr    */
TMOD=0x20;                   /* TMOD: timer 1, mode 2, 8-bit reload      */
TH1=0x0CC;                  /* TH1:  reload value for 1200 baud         */
TR1=1;                      /* TR1:  timer 1 run                        */
IE=0x90;
while(1);
}
void ISR_Serial(void)interrupt 4        //Subroutine for Interrupt
{
char c;
c=SBUF;  
IE=0x00;                      //Turning off interrupt to prevent recursion
if(RB8==PSW.0){
if(c==0x0d)
   {
   P1.4=~P1.4;                                
   SBUF='A';                 //Sending back "ACK" as   Acknowledgement 
   while(TI==0);
   TI=0;
   SBUF='C';
   while(TI==0);
   TI=0;
   SBUF='K';
    while(TI==0);
    TI=0;
    }
}
RI=0;
IE=0x90;                            //Reactivating the interrupt
}
